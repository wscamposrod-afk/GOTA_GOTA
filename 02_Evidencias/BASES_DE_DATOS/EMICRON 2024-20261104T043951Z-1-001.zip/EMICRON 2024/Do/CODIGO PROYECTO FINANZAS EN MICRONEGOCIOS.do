*******************************************************
* PROYECTO: FINANCIACIÓN INFORMAL DE MICRONEGOCIOS
* FUENTE: EMICRON 2024 - DANE
* OBJETIVO:
* Analizar el uso de financiación tipo "gota a gota"
* por ciudad y actividad económica.
*******************************************************

clear all
set more off

*******************************************************
* 1. RUTAS
*******************************************************

global ruta "C:\Users\user\Desktop\EMICRON 2024"

global identificacion "C:\Users\user\Desktop\EMICRON 2024\IDENTIFICACIÓN"
global inclusion "C:\Users\user\Desktop\EMICRON 2024\INCLUSION"
global resultados "C:\Users\user\Desktop\EMICRON 2024\RESULTADOS"


*******************************************************
* 2. CARGAR MÓDULO DE IDENTIFICACIÓN
*******************************************************

use "C:\Users\user\Desktop\EMICRON 2024\IDENTIFICACIÓN\Módulo de identificación.dta", clear

* Número de observaciones
count

* Revisar estructura
describe

*******************************************************
* 3. VERIFICAR IDENTIFICADORES
*******************************************************

isid DIRECTORIO SECUENCIA_P SECUENCIA_ENCUESTA

* Si el comando anterior no genera error,
* la combinación identifica de manera única
* cada micronegocio.


*******************************************************
* 4. REVISAR VARIABLES TERRITORIALES Y ECONÓMICAS
*******************************************************

tab AREA, missing

tab COD_DEPTO, missing

tab GRUPOS4, missing

tab GRUPOS12, missing


*******************************************************
* 5. GUARDAR TEMPORALMENTE LA IDENTIFICACIÓN
*******************************************************

save "$resultados\identificacion_temp.dta", replace


*******************************************************
* 6. CARGAR MÓDULO DE INCLUSIÓN FINANCIERA
*******************************************************

use "C:\Users\user\Desktop\EMICRON 2024\INCLUSION\Módulo de inclusión financiera.dta", clear

count

describe


*******************************************************
* 7. VERIFICAR IDENTIFICADORES DEL MÓDULO FINANCIERO
*******************************************************

isid DIRECTORIO SECUENCIA_P SECUENCIA_ENCUESTA


*******************************************************
* 8. REVISAR VARIABLES PRINCIPALES DE CRÉDITO
*******************************************************

tab P1765, missing

tab P1569, missing


*******************************************************
* 9. UNIR LOS DOS MÓDULOS
*******************************************************

merge 1:1 DIRECTORIO SECUENCIA_P SECUENCIA_ENCUESTA ///
using "$resultados\identificacion_temp.dta"


*******************************************************
* 10. REVISAR RESULTADO DEL MERGE
*******************************************************

tab _merge


*******************************************************
* 11. CONSERVAR SOLAMENTE OBSERVACIONES
*     CORRECTAMENTE EMPAREJADAS
*******************************************************

keep if _merge == 3

drop _merge


*******************************************************
* 12. GUARDAR BASE UNIFICADA
*******************************************************

save "$resultados\EMICRON_2024_financiamiento.dta", replace


*******************************************************
* FIN DEL BLOQUE DE UNIÓN
*******************************************************
*TRABAJO CON BASE DE DATOS UNIDA:
describe AREA COD_DEPTO GRUPOS4 GRUPOS12
*PARA VER CIUDADES:
tab AREA
*PARA VER DEPARTAMENTOS:
tab COD_DEPTO
*SOLICITO O NO FINANCIAMINETO:
tab P1765


*PARA VER LAS FUENTES DE CREDITO:
tab P1569

*******************************************************
* 12. CONSTRUCCIÓN DE VARIABLES DE ANÁLISIS
*******************************************************

* 12.1. Variable de solicitud de crédito
gen solicito_credito = (P1765 == 1) if !missing(P1765)

label define credito 0 "No solicitó crédito" ///
                     1 "Solicitó crédito"

label values solicito_credito credito


* 12.2. Variable de uso de crédito "gota a gota"
gen gota_gota = (P1569 == 5) if !missing(P1569)

label define gota 0 "Otra fuente de crédito" ///
                  1 "Prestamista / gota a gota"

label values gota_gota gota

*TAB NUEVAS VARIABLES:

tab solicito_credito, missing
tab gota_gota, missing
tab gota_gota solicito_credito, missing

*******************************************************
* 13. USO DE GOTA A GOTA POR CIUDAD
*    ANÁLISIS EXPLORATORIO NO PONDERADO
*******************************************************

tab AREA gota_gota if solicito_credito == 1, row

tab AREA gota_gota, row

tab GRUPOS4 gota_gota if solicito_credito == 1, row

tab GRUPOS4 gota_gota if solicito_credito == 1 & !missing(AREA), row

tab AREA GRUPOS4 if solicito_credito == 1 & gota_gota == 1, row

table AREA GRUPOS4 if solicito_credito == 1 & !missing(AREA), statistic(mean gota_gota)

*QUE VALOR HAY DETRAS DE CADA PORCENTAJE EN EL USOD EL GOTA GOTA POR SECTOR POR CIUDAD

table AREA GRUPOS4 if solicito_credito == 1 & !missing(AREA), statistic(count gota_gota) statistic(mean gota_gota)